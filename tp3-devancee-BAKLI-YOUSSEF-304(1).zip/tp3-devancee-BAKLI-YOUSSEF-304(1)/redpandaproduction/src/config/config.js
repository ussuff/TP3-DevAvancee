import 'dotenv/config'


export const getConfigNumber = () => {

    let signe = process.env.SIGNED

    if (signe === "false" || signe !== "true")
        signe = false
    else signe = signe === "true";

    return {
        integerSize: Number(process.env.INTEGER_SIZE),
        decimalValue: Number(process.env.DECIMAL_VALUE),
        signed: signe
    };
}

export const getTypeMessage = () => {
    return process.env.MESSAGE
}

export const getTimeOut = () => {
    return Number(process.env.PERIODE_MS) || 5000

}

export const getTopic = () => {
    return process.env.TOPIC || "topic-test"
}

export const getDebug = () => {
    return process.env.DEBUG === "true"
}

export const getBrokerAddress = () => {
    return process.env.HOST_IP || "localhost:9092";  // Si HOST_IP est vide, on prend localhost
};

export const getNumberWord = () => {
    return Number(process.env.NUMBER_WORD) || 3;  // 3 est une valeur par défaut
};
