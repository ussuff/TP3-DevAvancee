import express from "express";
import { createClient } from "redis";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// On se connecte
const client = createClient({
    url: "redis://localhost:6379"
});

client.connect().then(() => {
    console.log("✅ Connecté à Redis");
}).catch(console.error);

app.use(cors());
app.use(express.json());


app.get("/words", async (req, res) => {
    try {
        const keys = await client.keys("*"); // Récupère tous les mots
        const wordCounts = {};

        for (const key of keys) {
            const count = await client.get(key);
            wordCounts[key] = parseInt(count, 10);
        }

        res.json(wordCounts);
    } catch (error) {
        console.error("❌ Erreur API :", error);
        res.status(500).json({ error: "Erreur lors de la récupération des données" });
    }
});

// on lance le serveur
app.listen(PORT, () => {
    console.log(`🚀 Serveur API démarré sur http://localhost:${PORT}`);
});
