import React, { useState, useEffect } from "react";
import axios from "axios";

function App() {
    const [words, setWords] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get("http://localhost:5000/words");
                setWords(response.data);
                setLoading(false);
            } catch (error) {
                console.error("❌ Erreur lors de la récupération des données :", error);
            }
        };

        fetchData();
        const interval = setInterval(fetchData, 2000); // Mise à jour toutes les 2s

        return () => clearInterval(interval);
    }, []);

    // Trier les mots par ordre décroissant d'occurrences
    const sortedWords = Object.entries(words)
        .sort((a, b) => b[1] - a[1]);

    return (
        <div style={styles.container}>
            <h1 style={styles.title}>📝 Fréquence des mots</h1>

            {loading ? (
                <p style={styles.loading}>Chargement des données...</p>
            ) : (
                <table style={styles.table}>
                    <thead>
                        <tr>
                            <th style={styles.th}>Mot</th>
                            <th style={styles.th}>Occurrences</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedWords.map(([word, count], index) => (
                            <tr key={word} style={index < 3 ? styles.highlightRow : styles.tr}>
                                <td style={styles.td}>{word}</td>
                                <td style={styles.td}>{count}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}

const styles = {
    container: {
        textAlign: "center",
        padding: "20px",
        fontFamily: "Arial, sans-serif",
        backgroundColor: "#f4f4f4",
        minHeight: "100vh",
    },
    title: {
        fontSize: "28px",
        fontWeight: "bold",
        marginBottom: "20px",
    },
    loading: {
        fontSize: "18px",
        color: "#555",
    },
    table: {
        width: "60%",
        margin: "auto",
        borderCollapse: "collapse",
        backgroundColor: "#fff",
        boxShadow: "0 0 10px rgba(0,0,0,0.1)",
        borderRadius: "10px",
        overflow: "hidden",
    },
    th: {
        backgroundColor: "#007BFF",
        color: "#fff",
        padding: "12px",
        fontSize: "16px",
    },
    tr: {
        backgroundColor: "#f9f9f9",
    },
    highlightRow: {
        backgroundColor: "#FFD700",
        fontWeight: "bold",
    },
    td: {
        padding: "10px",
        borderBottom: "1px solid #ddd",
        fontSize: "14px",
    },
};

export default App;
