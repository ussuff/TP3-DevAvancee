import { Kafka } from "kafkajs";
import dotenv from "dotenv";
import { createClient } from "redis";

dotenv.config();

const client = createClient({
    url: "redis://localhost:6379"
});

client.connect().then(() => {
    console.log("✅ Connecté à Redis");
}).catch(console.error);

const kafka = new Kafka({
    clientId: "consommateur",
    brokers: ["localhost:9092"],
});

const consumer = kafka.consumer({ groupId: "groupe-consommateur" });

const run = async () => {
    await consumer.connect();
    console.log("✅ Connecté à RedPanda");

    await consumer.subscribe({ topic: "mon-super-topic", fromBeginning: true });

    await consumer.run({
        eachMessage: async ({ message }) => {
            const texte = message.value.toString();
            console.log(`📩 Message reçu : ${texte}`);
    
            try {

                const data = JSON.parse(texte);
                if (!data.message) return;
    

                const mots = data.message
                    .split(/\s+/)
                    .map(m => m.toLowerCase().replace(/[^a-z]/g, ""))
                    .filter(m => m.length > 0);
    
                // Incrémenter les mots dans Redis
                for (const mot of mots) {
                    await client.incr(mot);
                    console.log(` Mot "${mot}" -> incrémenté dans Redis`);
                }
            } catch (error) {
                console.error(" Erreur JSON :", error);
            }
        }
    });
    
    
};


run().catch(console.error);
